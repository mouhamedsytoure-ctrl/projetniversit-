<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;
use Illuminate\Support\Facades\DB;

return new class extends Migration {
    private function dbName(): string
    {
        return DB::selectOne('select database() as db')->db;
    }

    private function columnExists(string $table, string $column): bool
    {
        return DB::table('information_schema.columns')
            ->where('table_schema', $this->dbName())
            ->where('table_name', $table)
            ->where('column_name', $column)
            ->exists();
    }

    private function indexExists(string $table, string $indexName): bool
    {
        return DB::table('information_schema.statistics')
            ->where('table_schema', $this->dbName())
            ->where('table_name', $table)
            ->where('index_name', $indexName)
            ->exists();
    }

    private function foreignConstraintName(string $table, string $column): ?string
    {
        $row = DB::table('information_schema.key_column_usage')
            ->select('constraint_name')
            ->where('table_schema', $this->dbName())
            ->where('table_name', $table)
            ->where('column_name', $column)
            ->whereNotNull('referenced_table_name')
            ->first();

        return $row?->constraint_name;
    }

    public function up(): void
    {
        Schema::table('modules', function (Blueprint $table) {
            if (!Schema::hasColumn('modules', 'semestre_id')) {
                $table->foreignId('semestre_id')
                    ->after('niveau_id')
                    ->constrained('semestres')
                    ->cascadeOnDelete();
            }
        });

        if ($this->columnExists('documents_notes', 'semestre_id')) {
            if ($name = $this->foreignConstraintName('documents_notes', 'semestre_id')) {
                DB::statement('ALTER TABLE documents_notes DROP FOREIGN KEY '.$name);
            }
            if ($this->indexExists('documents_notes', 'documents_notes_module_id_semestre_id_index')) {
                DB::statement('ALTER TABLE documents_notes DROP INDEX documents_notes_module_id_semestre_id_index');
            }
            Schema::table('documents_notes', function (Blueprint $table) {
                $table->dropColumn('semestre_id');
            });
        }

        if ($this->columnExists('etudiants', 'filiere_id')) {
            if ($name = $this->foreignConstraintName('etudiants', 'filiere_id')) {
                DB::statement('ALTER TABLE etudiants DROP FOREIGN KEY '.$name);
            }
            if ($this->indexExists('etudiants', 'etudiants_filiere_id_niveau_id_index')) {
                DB::statement('ALTER TABLE etudiants DROP INDEX etudiants_filiere_id_niveau_id_index');
            }
            Schema::table('etudiants', function (Blueprint $table) {
                $table->dropColumn('filiere_id');
            });
        }

        if ($this->columnExists('notes', 'module_id')) {
            if ($this->indexExists('notes', 'notes_unique_key')) {
                DB::statement('ALTER TABLE notes DROP INDEX notes_unique_key');
            }
            if ($name = $this->foreignConstraintName('notes', 'module_id')) {
                DB::statement('ALTER TABLE notes DROP FOREIGN KEY '.$name);
            }
            Schema::table('notes', function (Blueprint $table) {
                $table->dropColumn('module_id');
            });
        }
    }

    public function down(): void
    {
        Schema::table('notes', function (Blueprint $table) {
            if (!Schema::hasColumn('notes', 'module_id')) {
                $table->foreignId('module_id')
                    ->after('etudiant_id')
                    ->constrained('modules')
                    ->restrictOnDelete();
            }
            if (!$this->indexExists('notes', 'notes_unique_key')) {
                $table->unique(['document_note_id', 'etudiant_id', 'module_id', 'type', 'session'], 'notes_unique_key');
            }
        });

        Schema::table('etudiants', function (Blueprint $table) {
            if (!Schema::hasColumn('etudiants', 'filiere_id')) {
                $table->foreignId('filiere_id')
                    ->after('sexe')
                    ->constrained('filieres')
                    ->restrictOnDelete();
            }
            if (!$this->indexExists('etudiants', 'etudiants_filiere_id_niveau_id_index')) {
                $table->index(['filiere_id', 'niveau_id']);
            }
        });

        Schema::table('documents_notes', function (Blueprint $table) {
            if (!Schema::hasColumn('documents_notes', 'semestre_id')) {
                $table->foreignId('semestre_id')
                    ->after('module_id')
                    ->constrained('semestres')
                    ->restrictOnDelete();
            }
            if (!$this->indexExists('documents_notes', 'documents_notes_module_id_semestre_id_index')) {
                $table->index(['module_id', 'semestre_id']);
            }
        });

        Schema::table('modules', function (Blueprint $table) {
            if (Schema::hasColumn('modules', 'semestre_id')) {
                $table->dropForeign(['semestre_id']);
                $table->dropColumn('semestre_id');
            }
        });
    }
};