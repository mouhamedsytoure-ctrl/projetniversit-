<?php

namespace App\Http\Controllers\Auth;

use App\Http\Controllers\Controller;
use Illuminate\Http\RedirectResponse;

class RegisteredUserController extends Controller
{
    public function create(): RedirectResponse
    {
        abort(403, 'Inscription désactivée.');
    }

    public function store(): RedirectResponse
    {
        abort(403, 'Inscription désactivée.');
    }
}